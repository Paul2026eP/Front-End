function mostrarSecao(id, elemento) {
    // 1. Esconder todas as seções
    const secoes = document.querySelectorAll('main section');
    secoes.forEach(s => s.classList.remove('visivel'));
  
    // 2. Mostrar a seção clicada
    document.getElementById(id).classList.add('visivel');
  
    // 3. Mudar a cor do link no menu
    const links = document.querySelectorAll('nav a');
    links.forEach(l => l.classList.remove('ativo'));
    elemento.classList.add('ativo');
  }