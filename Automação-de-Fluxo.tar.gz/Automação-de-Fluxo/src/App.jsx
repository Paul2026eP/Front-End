import { useState } from 'react';
import './App.css';

function App() {
  const [userInput, setUserInput] = useState('');
  const [flowHistory, setFlowHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Simulação de "Busca na Internet/IA" em cada etapa
  const simulateTask = async (taskName, query) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`[${taskName}] Resultados para '${query}': Dados analisados e processados autonomamente.`);
      }, 1500); // 1.5s delay por etapa
    });
  };

  const startComplexFlow = async () => {
    if (!userInput) return;
    setIsLoading(true);
    setFlowHistory([]); // Reseta o histórico

    const steps = [
      { name: "Análise de Contexto", query: userInput },
      { name: "Busca e Verificação", query: `web search: ${userInput}` },
      { name: "Processamento de Dados", query: "processando " + userInput },
      { name: "Geração de Relatório", query: "finalizando" }
    ];

    let currentContext = userInput;
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      const result = await simulateTask(step.name, step.query);
      
      setFlowHistory(prev => [...prev, { step: step.name, result }]);
      
      // Simula que o resultado de uma etapa vira contexto da próxima
      currentContext = result; 
    }

    setIsLoading(false);
  };

  return (
    <div className="container">
      <header>
        <h1>Automação de Fluxos</h1>
        <p>Substitua agentes manuais por fluxos de trabalho autónomos.</p>
      </header>

      <div className="input-area">
        <textarea
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Descreva o objetivo do fluxo (ex: 'Pesquisar o preço do café no Brasil e criar um resumo')"
          rows={3}
        />
        <button onClick={startComplexFlow} disabled={isLoading || !userInput}>
          {isLoading ? 'Processando...' : 'Iniciar Fluxo'}
        </button>
      </div>

      <div className="flow-display">
        {flowHistory.map((item, index) => (
          <div key={index} className="flow-step">
            <span className="step-tag">{item.step}</span>
            <p>{item.result}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
