import React from 'react';

const Frase = ({ index }) => {
  const mensagens = [
    "Olá Mundo",
    "Bem-vindo ao React",
    "Fim da Prova de LPBE"
  ];

  return <p>{mensagens[index]}</p>;
};

export default Frase;
