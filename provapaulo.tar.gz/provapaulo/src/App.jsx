import React from 'react';
import Frase from './Frase';

const App = () => {
  const multiplicar = (a, b) => a * b;

  return (
    <div style={{ textAlign: 'center' }}> 
      <p>Prova de LPBE</p>
      <p>Valor: {multiplicar(5, 10)}</p> 
      
      <div>  
        <img src="favicon.svg" alt="Imagem" style={{ width: '50px' }} />
        <p>FAVICON</p>
      </div>

      <div style={{ marginTop: '20px' }}>
        <Frase index={0} />
        <Frase index={1} />
        <Frase index={2} />
      </div>
    </div>
  );
};

export default App;
