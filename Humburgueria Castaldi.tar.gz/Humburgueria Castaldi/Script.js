function mostrarSecao(id, linkClicado){
    document.querySelectorAll ('main sections'),forEach(sec =>{
        sec.classList.remove("visivel")
    });

document.getElementById(id).classList.add ("visivel");
linkClicado.classList.add('ativo');
}                                             