import React, { useState } from 'react';
import './App.css';

export default function App() {
  const [inputPrompt, setInputPrompt] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [nlpData, setNlpData] = useState(null);
  const [outputData, setOutputData] = useState('');

  // Etapas explícitas do Pipeline de Compilação/PLN e Varredura Web
  const workflowSteps = [
    { id: 1, label: 'Tokenização e Análise Léxica (Divisão de símbolos e validação)' },
    { id: 2, label: 'Análise Sintática e Semântica (Árvore gramatical e extração de sentido)' },
    { id: 3, label: 'Análise Pragmática (Interpretação do contexto de uso e intenção)' },
    { id: 4, label: 'Varredura Web e Grounding (Requisição simulada ao Copilot MS / Bing)' }
  ];

  const executeComplexWorkflow = async () => {
    if (!inputPrompt.trim()) return;

    setIsRunning(true);
    setCurrentStep(1);
    setOutputData('');
    setNlpData(null);

    // --- ETAPA 1: Tokenização e Léxica ---
    await new Promise((resolve) => setTimeout(resolve, 1800));
    const rawTokens = inputPrompt.toLowerCase().split(/[\s,;.?!]+/).filter(Boolean);
    const stopWords = ['o', 'a', 'os', 'as', 'de', 'do', 'da', 'em', 'para', 'que', 'com', 'no', 'na'];
    const filteredTokens = rawTokens.filter(t => !stopWords.includes(t));
    
    setNlpData(prev => ({
      ...prev,
      tokens: rawTokens,
      lexical: filteredTokens
    }));

    // --- ETAPA 2: Sintática e Semântica ---
    setCurrentStep(2);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    // Identificação básica de verbos/padrões para simular regras sintáticas
    const actions = rawTokens.filter(t => ['buscar', 'analisar', 'comparar', 'encontrar', 'criar', 'monitorar'].includes(t));
    const coreSubject = filteredTokens.slice(-2).join(' ') || 'Assunto Geral';

    setNlpData(prev => ({
      ...prev,
      syntaxTree: `[Orações: Ativa] -> Verbo(s) Detectado(s): [${actions.join(', ') || 'Implicitado'}]`,
      semantics: `Entidade Alvo Reconhecida: "${coreSubject}" | Tipo: Consulta Baseada em Intenção Web`
    }));

    // --- ETAPA 3: Pragmática ---
    setCurrentStep(3);
    await new Promise((resolve) => setTimeout(resolve, 1800));
    
    setNlpData(prev => ({
      ...prev,
      pragmatics: `Intenção do Usuário: Extração de Inteligência Competitiva. Contexto situacional avaliado com sucesso sem ambiguidades.`
    }));

    // --- ETAPA 4: Varredura Copilot MS / Bing ---
    setCurrentStep(4);
    await new Promise((resolve) => setTimeout(resolve, 2500));

    // Geração do output final fundamentado
    setOutputData(
      `[MÓDULO WEB SCRAPER - INTEGRAÇÃO COPILOT MS / BING GROUNDING]\n\n` +
      `🔍 Orquestrador executou busca profunda para: "${coreSubject}"\n` +
      `🌐 Fontes Varridas: index.copilot.microsoft.com, Bing Knowledge Graph, Documentações Oficiais.\n\n` +
      `[RESULTADOS ENCONTRADOS EM TEMPO REAL]\n` +
      `1. Tendência de Mercado: O ecossistema em torno de "${coreSubject}" aponta forte crescimento em automação assíncrona.\n` +
      `2. Dados Consolidados: Indexadores identificaram referências ativas de mercado indicando alta demanda por soluções que evitam custos com infraestrutura de chat tradicional.\n` +
      `3. Resumo Executivo: Solicitação processada com sucesso no pipeline linguístico. Resposta limpa de alucinações e otimizada via inteligência web.`
    );
    
    setIsRunning(false);
  };

  return (
    <div className="app-container">
      <header>
        <h1>Autonomous Multi-Agent Workflow</h1>
        <p>Substitua fluxos baseados em chat por processos assíncronos orientados a objetivos</p>
      </header>

      <div className="grid-layout">
        {/* Painel de Entrada e Progresso */}
        <div className="card">
          <h2>Configuração do Fluxo</h2>
          <div className="input-group">
            <label htmlFor="prompt">Descreva o objetivo final do fluxo de trabalho:</label>
            <textarea
              id="prompt"
              placeholder="Ex: Buscar tendências sobre Inteligência Artificial e analisar concorrência."
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              disabled={isRunning}
            />
            <button 
              onClick={executeComplexWorkflow} 
              disabled={isRunning || !inputPrompt.trim()}
            >
              {isRunning ? 'Processando Pipeline...' : 'Iniciar Processo Autônomo'}
            </button>
          </div>

          <div className="steps-container" style={{ marginTop: '2rem' }}>
            <h3>Etapas de Execução Atuais</h3>
            <div className="steps-list">
              {workflowSteps.map((step) => {
                let statusClass = 'pending';
                let icon = '⚪';
                
                if (isRunning && currentStep === step.id) {
                  statusClass = 'running';
                  icon = '⚙️';
                } else if (currentStep > step.id || (outputData && !isRunning)) {
                  statusClass = 'completed';
                  icon = '✅';
                }

                return (
                  <div key={step.id} className={`step-item ${statusClass}`}>
                    <span className="status-icon">{icon}</span>
                    <span>{step.label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Painel de Saída e Debug do Compilador/PLN */}
        <div className="card">
          <h2>Saída de Contexto & Logs de Compilação</h2>
          <div className="output-content">
            {nlpData && (
              <div className="nlp-debug-box" style={{ marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border)', fontSize: '0.9rem' }}>
                <strong style={{ color: 'var(--accent)' }}>[LOGS DO PIPELINE COMPILADOR]:</strong>
                <div style={{ marginTop: '0.5rem' }}><strong>Tokens:</strong> {JSON.stringify(nlpData.tokens)}</div>
                <div><strong>Léxica (Filtrada):</strong> {JSON.stringify(nlpData.lexical)}</div>
                {nlpData.syntaxTree && <div><strong>Sintática:</strong> {nlpData.syntaxTree}</div>}
                {nlpData.semantics && <div><strong>Semântica:</strong> {nlpData.semantics}</div>}
                {nlpData.pragmatics && <div><strong>Pragmática:</strong> {nlpData.pragmatics}</div>}
              </div>
            )}
            
            {outputData ? (
              <div style={{ whiteSpace: 'pre-wrap' }}>{outputData}</div>
            ) : isRunning ? (
              <span style={{ color: 'var(--text-muted)' }}>O pipeline linguístico está ativo e consultando o Copilot MS...</span>
            ) : (
              <span style={{ color: 'var(--text-muted)' }}>Aguardando a inserção de dados para iniciar o processamento compilado.</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
